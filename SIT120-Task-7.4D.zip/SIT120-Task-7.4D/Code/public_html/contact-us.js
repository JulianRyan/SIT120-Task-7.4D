function commentValidation() {
    returnStatement = true;
    firstName = document.getElementById("nameInput").value;
    comment = document.getElementById("commentInput").value;
    if (firstName == "" || comment == "") {
        returnStatement = false;
    }
    if (returnStatement == false) {
        if (firstName == "") {
            document.getElementById("nameInput").className = "form-control is-invalid";
            document.getElementById("nameMessage").innerHTML = "Please enter your name"
            document.getElementById("nameMessage").className = "text-danger"
        }
        else {
            document.getElementById("nameInput").className = "form-control is-valid";
            document.getElementById("nameMessage").innerHTML = "Name input is correct"
            document.getElementById("nameMessage").className = "text-success"
        }

        if (comment == "") {
            document.getElementById("commentInput").className = "form-control is-invalid";
            document.getElementById("commentMessage").innerHTML = "Please enter a comment"
            document.getElementById("commentMessage").className = "text-danger"
        }
        else {
            document.getElementById("commentInput").className = "form-control is-valid";
            document.getElementById("commentMessage").innerHTML = "Comment input is correct"
            document.getElementById("commentMessage").className = "text-success"
        }
    }
    else {
        console.log("message sent")
        document.getElementById("nameInput").className = "form-control";
        document.getElementById("nameMessage").innerHTML = ""
        document.getElementById("nameMessage").className = ""

        document.getElementById("commentInput").className = "form-control";
        document.getElementById("commentMessage").innerHTML = ""
        document.getElementById("commentMessage").className = ""
    }
}