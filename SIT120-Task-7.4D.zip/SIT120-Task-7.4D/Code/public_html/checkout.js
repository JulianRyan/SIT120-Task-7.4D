function updateForm(option) {
    product_count = document.getElementsByClassName('product').length
    for (var i = 0; i < product_count; i++) {
        type = document.getElementsByClassName('form-control border-0 ' + option)[i].value
        quantity = document.getElementsByClassName('form-control border-0 ' + option)[i].value
        if (option == "largerInputOption") {
            document.getElementsByClassName('form-control border-0 smallerInputOption')[i].value = type
        }
        else if (option == "largerInputQuantity") {
            console.log()
            document.getElementsByClassName('form-control border-0 smallerInputQuantity')[i].value = quantity
            document.getElementsByClassName('form-control border-0 smallerInputQuantity')[i].innerHTML = quantity
        }
        else if (option == "smallerInputOption") {
            document.getElementsByClassName('form-control border-0 largerInputOption')[i].value = type
        }
        else if (option == "smallerInputQuantity") {
            document.getElementsByClassName('form-control border-0 largerInputQuantity')[i].value = quantity
            document.getElementsByClassName('form-control border-0 largerInputQuantity')[i].innerHTML = quantity
        }
    }
}

function validatePurchase() {

    // Validate products
    returnStatement = true;
    product_count = document.getElementsByClassName('product').length
    for (var i = 0; i < product_count; i++) {
        if (document.getElementsByClassName('form-control border-0 largerInputOption')[i].disabled == true) {
            type = "Not required"
        }
        else {
            type = document.getElementsByClassName('form-control border-0 largerInputOption')[i].value
        }
        quantity = document.getElementsByClassName('form-control border-0 largerInputQuantity')[i].value
        console.log(type)
        console.log(quantity)

        if (type == "") {
            document.getElementsByClassName('form-control border-0 largerInputOption')[i].className = "form-control border-0 largerInputOption is-invalid";
            document.getElementsByClassName("largerTypeMessage")[i].innerHTML = "Please enter a type for your product"
            document.getElementsByClassName("largerTypeMessage")[i].className = "largerTypeMessage text-danger"
            document.getElementsByClassName('form-control border-0 smallerInputOption')[i].className = "form-control border-0 smallerInputOption is-invalid";
            document.getElementsByClassName("smallerTypeMessage")[i].innerHTML = "Please enter a type for your product"
            document.getElementsByClassName("smallerTypeMessage")[i].className = "smallerTypeMessage text-danger"
            
            returnStatement = false;
        }
        else {
            document.getElementsByClassName('form-control border-0 largerInputOption')[i].className = "form-control border-0 largerInputOption is-valid";
            document.getElementsByClassName("largerTypeMessage")[i].innerHTML = "Type input is correct"
            document.getElementsByClassName("largerTypeMessage")[i].className = "largerTypeMessage text-success"
            document.getElementsByClassName('form-control border-0 smallerInputOption')[i].className = "form-control border-0 smallerInputOption is-valid";
            document.getElementsByClassName("smallerTypeMessage")[i].innerHTML = "Type input is correct"
            document.getElementsByClassName("smallerTypeMessage")[i].className = "smallerTypeMessage text-success"
        }

        if (quantity <= 0) {
            document.getElementsByClassName('form-control border-0 largerInputQuantity')[i].className = "form-control border-0 largerInputQuantity is-invalid";
            document.getElementsByClassName("largerQuantityMessage")[i].innerHTML = "Please enter a type for your product"
            document.getElementsByClassName("largerQuantityMessage")[i].className = "largerQuantityMessage text-danger"
            document.getElementsByClassName('form-control border-0 smallerInputQuantity')[i].className = "form-control border-0 smallerInputQuantity is-invalid";
            document.getElementsByClassName("smallerQuantityMessage")[i].innerHTML = "Please enter a type for your product"
            document.getElementsByClassName("smallerQuantityMessage")[i].className = "smallerQuantityMessage text-danger"
            returnStatement = false;
        }
        else {
            document.getElementsByClassName('form-control border-0 largerInputQuantity')[i].className = "form-control border-0 largerInputQuantity is-valid";
            document.getElementsByClassName("largerQuantityMessage")[i].innerHTML = "Quantity input is correct"
            document.getElementsByClassName("largerQuantityMessage")[i].className = "largerQuantityMessage text-success"
            document.getElementsByClassName('form-control border-0 smallerInputQuantity')[i].className = "form-control border-0 smallerInputQuantity is-valid";
            document.getElementsByClassName("smallerQuantityMessage")[i].innerHTML = "Quantity input is correct"
            document.getElementsByClassName("smallerQuantityMessage")[i].className = "smallerQuantityMessage text-success"
        }
    }


    //Validate purchase
    firstName = document.getElementById("firstnameInput").value;
    lastName = document.getElementById("lastnameInput").value;
    email = document.getElementById("emailInput").value;
    phone = document.getElementById("phoneInput").value;
    address = document.getElementById("addressInput").value;
    suburb = document.getElementById("suburbInput").value;
    state = document.getElementById("stateInput").value;
    postcode = document.getElementById("postcodeInput").value;
    card = document.getElementById("cardInput").value;
    security = document.getElementById("securityInput").value;
    expiryMonth = document.getElementById("expiryMonthInput").value;
    expiryYear = document.getElementById("expiryYearInput").value;

    var phonePattern = /[0-9]{10}/;
    var securityPattern = /[0-9]{3}/;
    var postcodePattern = /[0-9]{4}/;
    var cardPattern = /[0-9]{16}/;
    if (firstName == "") {
        document.getElementById("firstnameInput").className = "form-control is-invalid";
        document.getElementById("firstnameMessage").innerHTML = "Please enter a type for your product"
        document.getElementById("firstnameMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("firstnameInput").className = "form-control is-valid";
        document.getElementById("firstnameMessage").innerHTML = "Type input is correct"
        document.getElementById("firstnameMessage").className = "text-success"
    }

    if (lastName == "") {
        document.getElementById("lastnameInput").className = "form-control is-invalid";
        document.getElementById("lastnameMessage").innerHTML = "Please enter a type for your product"
        document.getElementById("lastnameMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("lastnameInput").className = "form-control is-valid";
        document.getElementById("lastnameMessage").innerHTML = "Type input is correct"
        document.getElementById("lastnameMessage").className = "text-success"
    }

    if (email == "") {
        document.getElementById("emailInput").className = "form-control is-invalid";
        document.getElementById("emailMessage").innerHTML = "Please enter your email address"
        document.getElementById("emailMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("emailInput").className = "form-control is-valid";
        document.getElementById("emailMessage").innerHTML = "Email input is correct"
        document.getElementById("emailMessage").className = "text-success"
    }

    if (phone == "") {
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Please enter your phone number"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (phone.length != 10) {
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Phone has an invalid length"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (phonePattern.test(phone) == false) {
        leftoverCharacters = phone.replace(/([0-9])/gi, '');
        document.getElementById("phoneInput").className = "form-control is-invalid";
        document.getElementById("phoneMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("phoneMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("phoneInput").className = "form-control is-valid";
        document.getElementById("phoneMessage").innerHTML = "Phone number input is correct"
        document.getElementById("phoneMessage").className = "text-success"
    }




    if (address == "") {
        document.getElementById("addressInput").className = "form-control is-invalid";
        document.getElementById("addressMessage").innerHTML = "Please enter your address correctly"
        document.getElementById("addressMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("addressInput").className = "form-control is-valid";
        document.getElementById("addressMessage").innerHTML = "Type input is correct"
        document.getElementById("addressMessage").className = "text-success"
    }

    if (suburb == "") {
        document.getElementById("suburbInput").className = "form-control is-invalid";
        document.getElementById("suburbMessage").innerHTML = "Please enter your suburb correctly"
        document.getElementById("suburbMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("suburbInput").className = "form-control is-valid";
        document.getElementById("suburbMessage").innerHTML = "Type input is correct"
        document.getElementById("suburbMessage").className = "text-success"
    }

    if (state == "") {
        document.getElementById("stateInput").className = "form-control is-invalid";
        document.getElementById("stateMessage").innerHTML = "Please enter your suburb correctly"
        document.getElementById("stateMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("stateInput").className = "form-control is-valid";
        document.getElementById("stateMessage").innerHTML = "Type input is correct"
        document.getElementById("stateMessage").className = "text-success"
    }

    if (postcode == "") {
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Please enter your address correctly"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (postcode.length != 4) {
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Postcode has an invalid length"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (postcodePattern.test(postcode) == false) {
        leftoverCharacters = postcode.replace(/([0-9])/gi, '');
        document.getElementById("postcodeInput").className = "form-control is-invalid";
        document.getElementById("postcodeMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("postcodeMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("postcodeInput").className = "form-control is-valid";
        document.getElementById("postcodeMessage").innerHTML = "Type input is correct"
        document.getElementById("postcodeMessage").className = "text-success"
    }




    if (card == "") {
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Please enter your suburb correctly"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (card.length != 16) {
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Card number has an invalid length"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (cardPattern.test(card) == false) {
        leftoverCharacters = card.replace(/([0-9])/gi, '');
        document.getElementById("cardInput").className = "form-control is-invalid";
        document.getElementById("cardMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("cardMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("cardInput").className = "form-control is-valid";
        document.getElementById("cardMessage").innerHTML = "Type input is correct"
        document.getElementById("cardMessage").className = "text-success"
    }

    if (security == "") {
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Please enter your suburb correctly"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (security.length != 3) {
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Card number has an invalid length"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (securityPattern.test(security) == false) {
        leftoverCharacters = security.replace(/([0-9])/gi, '');
        document.getElementById("securityInput").className = "form-control is-invalid";
        document.getElementById("securityMessage").innerHTML = "Contains characters '" + leftoverCharacters + "'. Numbers only!"
        document.getElementById("securityMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("securityInput").className = "form-control is-valid";
        document.getElementById("securityMessage").innerHTML = "Type input is correct"
        document.getElementById("securityMessage").className = "text-success"
    }

    if (expiryMonth == "") {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (expiryMonth > 12 || expiryMonth < 1) {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if ((expiryMonth <= 12 || expiryMonth >= 1) && (expiryYear <= 31 || expiryYear >= 1)){
        document.getElementById("expiryMonthInput").className = "form-control is-valid";
        document.getElementById("expiryYearInput").className = "form-control is-valid";
        document.getElementById("expiryMessage").innerHTML = "Expiry date is correct"
        document.getElementById("expiryMessage").className = "text-success"
    }

    if (expiryYear == "") {
        document.getElementById("expiryYearInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }
    else if (expiryYear > 31 || expiryYear < 1) {
        document.getElementById("expiryMonthInput").className = "form-control is-invalid";
        document.getElementById("expiryMessage").innerHTML = "Please enter your expiry date correctly"
        document.getElementById("expiryMessage").className = "text-danger"
        returnStatement = false;
    }

    if (returnStatement == true) {
        document.location.href = "/home.html"
    }
}