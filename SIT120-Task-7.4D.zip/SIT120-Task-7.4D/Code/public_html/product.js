function productValidation() {
    returnStatement = true;
    type = document.getElementById("typeInput").value;
    if (type == "") {
        document.getElementById("typeInput").className = "form-control is-invalid";
        document.getElementById("typeMessage").innerHTML = "Please enter a type for your product"
        document.getElementById("typeMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("typeInput").className = "form-control is-valid";
        document.getElementById("typeMessage").innerHTML = "Type input is correct"
        document.getElementById("typeMessage").className = "text-success"
    }

    quantity = document.getElementById("quantityInput").value;
    if (quantity <= 0) {
        document.getElementById("quantityInput").className = "form-control is-invalid";
        document.getElementById("quantityMessage").innerHTML = "Please enter the quantity of items you would like"
        document.getElementById("quantityMessage").className = "text-danger"
        returnStatement = false;
    }
    else {
        document.getElementById("quantityInput").className = "form-control is-valid";
        document.getElementById("quantityMessage").innerHTML = "Quantity input is correct"
        document.getElementById("quantityMessage").className = "text-success"
    }
    if (returnStatement == true) {
        document.location.href = "/checkout.html"
    }
}

function commentValidation() {
    returnStatement = true;
    firstName = document.getElementById("nameInput").value;
    comment = document.getElementById("commentInput").value;
    rating = document.getElementById("ratingInput").value
    if (firstName == "" || comment == "" || (rating > 0 || rating <= 5) == false) {
        returnStatement = false;
    }
    if (returnStatement == false) {
        if (firstName == "") {
            document.getElementById("nameInput").className = "form-control is-invalid";
            document.getElementById("nameMessage").innerHTML = "Please enter your name"
            document.getElementById("nameMessage").className = "text-danger"
        }
        else {
            document.getElementById("nameInput").className = "form-control is-valid";
            document.getElementById("nameMessage").innerHTML = "Name input is correct"
            document.getElementById("nameMessage").className = "text-success"
        }

        if (comment == "") {
            document.getElementById("commentInput").className = "form-control is-invalid";
            document.getElementById("commentMessage").innerHTML = "Please enter a comment"
            document.getElementById("commentMessage").className = "text-danger"
        }
        else {
            document.getElementById("commentInput").className = "form-control is-valid";
            document.getElementById("commentMessage").innerHTML = "Comment input is correct"
            document.getElementById("commentMessage").className = "text-success"
        }

        rating = document.getElementById("ratingInput").value;
        if ((rating > 0 || rating <= 5) == false) {
            document.getElementById("ratingInput").className = "form-control text-center is-invalid";
            document.getElementById("ratingMessage").innerHTML = "Please enter a rating"
            document.getElementById("ratingMessage").className = "text-danger"
            returnStatement = false;
        }
        else {
            document.getElementById("ratingInput").className = "form-control text-center is-valid";
            document.getElementById("ratingMessage").innerHTML = "Rating input is correct"
            document.getElementById("ratingMessage").className = "text-success"
            document.getElementById("ratingMessage").value = 0
        }
    }
    else {
        console.log("message sent")
        document.getElementById("nameInput").className = "form-control";
        document.getElementById("nameMessage").innerHTML = ""
        document.getElementById("nameMessage").className = ""

        document.getElementById("commentInput").className = "form-control";
        document.getElementById("commentMessage").innerHTML = ""
        document.getElementById("commentMessage").className = ""

        document.getElementById("ratingInput").className = "form-control text-center";
        document.getElementById("ratingMessage").innerHTML = ""
        document.getElementById("ratingMessage").className = ""
    }
}

function displayRating(ratingInput) {
    var stars = document.getElementById("ratingInput").children
    for (var i = 0; i < stars.length; i++) {
        if (i < ratingInput) {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2605"
        }
        else {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2606"
        }
    }
}

function removeRating() {
    var stars = document.getElementById("ratingInput").children
    var value = document.getElementById("ratingInput").value
    for (var i = 0; i < stars.length; i++) {
        if (i < value)
        {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2605"
        }
        else
        {
            document.getElementById("ratingInput").children[i].innerHTML = "&#x2606" 
        }
    }
}

function inputRating(value)
{
    var stars = document.getElementById("ratingInput").children
    for (var i = 0; i < stars.length; i++) {
        if (value - 1 == i) {
            document.getElementById("ratingInput").value = value
        }
    }
}